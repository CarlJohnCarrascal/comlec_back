<?php echo e($slot); ?>

<?php /**PATH C:\Users\User\Documents\ALLBESTITSOLUTION\Election\Comlec-onlinecc\Comlec-onlinecc\comlec_back\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>