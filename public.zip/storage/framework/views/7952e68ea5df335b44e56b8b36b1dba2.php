<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\User\Documents\ALLBESTITSOLUTION\Election\Comlec-onlinecc\Comlec-onlinecc\comlec_back\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>